/* 
Author: Kendrick Nguyen
Date: 22 Janurary 2021
Description: Create a number guessing generator between 1 and 100 that checks the user's input and then gives them an appropiate output
*/

#include "CheckInput.h"
#include <iostream>
#include <cstdlib> //allows the random number function
#include <ctime> //allows different random numbers
using namespace std; //removes the need to std::

int main() {
  srand(time(NULL));
  int Userinput = 0; //init variable for the user input
  int tries = 0; //init variable for the number of tries the user does when guessing
  int randnum = rand() % 100 + 1; //random number generated

  cout << "Guess a number between (1-100): "; //Display for user

  while (Userinput != randnum){ //while loop for all possible inputs
    Userinput = getInt(); // if the input is not an Int, it will reply with an Invalid
    tries += 1;//tries counter

    if (Userinput < 1){ //outside the range
      cout << "Invalid.   Try again: ";
      tries -= 1;//since the try counter increases in each loop, if it is invalid, then -1 to tries so that the tries counter will not increase

    }else if (Userinput > 100){ //outside the range
      cout << "Invalid.   Try again: ";
      tries -= 1;

    }else if (Userinput < randnum){ //prompts user to guess higher
      cout << "Too low.   Guess another number: ";

    }else if (Userinput > randnum){ //prompts user to guess lower
      cout << "Too high.  Guess another number: ";
      
    }
  }
  cout << "You guessed the number in " << tries << " tries!"; //end result
}